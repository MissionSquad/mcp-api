# Sources

Sources for contract standards, best practices and other documentation.

## Tokens

### ERC20 (Common Token)

- https://eips.ethereum.org/EIPS/eip-20

### ERC721 (Standard NFT)

- https://eips.ethereum.org/EIPS/eip-721

### ERC1155 (MultiToken)

- https://eips.ethereum.org/EIPS/eip-1155

#### NFTs (ERC721, ERC1155)

- https://nftschool.dev/reference/metadata-schemas/#ethereum-and-evm-compatible-chains
- https://docs.ipfs.io/how-to/best-practices-for-nft-data/
- https://docs.opensea.io/docs/metadata-standards

### ERC1820 (Registry Contract)

- https://eips.ethereum.org/EIPS/eip-1820

## Proxies

### ERC897 (DelegateProxy)

- https://eips.ethereum.org/EIPS/eip-897

#### Polygon/Matic UpgradeableProxy

- https://github.com/maticnetwork/contracts/blob/aa633540910dd45c2e2775f5b7997ac4912f1c88/contracts/common/misc/UpgradableProxy.sol#L9

#### OpenZeppelin UpgradeableProxy

- https://github.com/OpenZeppelin/openzeppelin-labs/blob/2adc218c1969749598cf6aba178c914885fabad8/initializer_contracts/contracts/UpgradeabilityProxy.sol#L24

### ERC1167 (MinimalProxy)

- https://eips.ethereum.org/EIPS/eip-1167

### ERC1822 (Universal Upgradable Proxy)

- https://eips.ethereum.org/EIPS/eip-1822

### ERC1967 (Standard Proxy Storage Slots)

- https://eips.ethereum.org/EIPS/eip-1967

### ERC2535 (Diamonds / Multi-Facet Proxy)

- https://eips.ethereum.org/EIPS/eip-2535

- https://eip2535diamonds.substack.com/p/list-of-projects-using-eip-2535-diamonds
- https://louper.dev/ (Diamond Inspector)

### ERC3448 (MetaProxy)

- https://eips.ethereum.org/EIPS/eip-3448


## GnosisSafe

GnosisSafe is a well known and widely used proxied multisig wallet smart contract.

- https://github.com/gnosis/safe-contracts

## Defi

### ERC3156 (FlashLoans)

- https://eips.ethereum.org/EIPS/eip-3156
- https://eattheblocks.com/how-to-perform-custom-ethereum-flash-loans-using-solidity-erc-3156-standard/

## Resources

Solidity ABI Specification
- https://docs.soliditylang.org/en/v0.8.11/abi-spec.html

Ethereum ERC Proposals
- https://eips.ethereum.org/erc

OpenZeppelin Docs
- https://docs.openzeppelin.com/contracts

OpenZeppelin Proxies
- https://github.com/OpenZeppelin/openzeppelin-contracts/tree/v4.3.0/contracts/proxy 
- https://blog.openzeppelin.com/proxy-patterns/

Matic Network Contracts
- https://github.com/maticnetwork/contracts

AragonOS Docs
- https://hack.aragon.org/docs/aragonos-building

Aragon Apps
- https://github.com/aragon/aragon-apps