# Smart Contract Resources

## ABIs (Application Binary Interface)
Used in EVM transaction decoding. Each function can be reduced to a signature that is used to match and decode bytecode in transactions on EVM networks.

### Tools

[Function signature tool](https://piyolab.github.io/playground/ethereum/getEncodedFunctionSignature/)

[Full ABI Encoding tool](https://abi.hashex.org/)

---
### [Sources](sources.md)